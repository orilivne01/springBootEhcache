package com.example.demo2;

import java.io.Serializable;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TestReposetory extends JpaRepository<Test, Serializable> {
	@Cacheable(cacheNames= "test" )
	public Test findAllByTestName(String testName);
}
