package com.example.demo2;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.sf.ehcache.CacheManager;

@Service("TestService")
public class TestService {
	@Autowired
	TestReposetory testRepo;
	
	public void createTest(String testname){
		System.out.println(org.hibernate.Version.getVersionString());
		Test test = new Test(testname);
		testRepo.save(test);
	}
	public Test getTest(String testname){
		//List<CacheManager> tempManagers = CacheManager.ALL_CACHE_MANAGERS.get(0).;
		Test test  = testRepo.findAllByTestName(testname);
		return test;
	}
}
