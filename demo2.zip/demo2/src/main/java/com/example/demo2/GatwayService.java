package com.example.demo2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GatwayService {
	@Autowired
	TestService testService;
	@GetMapping(value="Test/CreateTest/{testname}")
	public void createTest(@PathVariable(value = "testname")String testname){
		testService.createTest(testname);
	}
	@GetMapping(value="Test/getTest/{testname}")
	public String getTest(@PathVariable(value = "testname")String testname){
		Test test = testService.getTest(testname);
		return test.toString();
	}
}
