package com.example.demo2;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.cache.annotation.Cacheable;

@Entity
@Table(name = "TEST")
@Cacheable
@org.hibernate.annotations.Cache(usage = org.hibernate.annotations.CacheConcurrencyStrategy.READ_WRITE ,region = "test") //Provide cache strategy.
public class Test implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue
	Long id;
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	String testName;

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
				this.testName = testName;
	}
	Test(){
		
	}
	Test(String name){
		testName = name;
	}
	public String toString(){
		return String.valueOf(id)+testName;
	}
}
